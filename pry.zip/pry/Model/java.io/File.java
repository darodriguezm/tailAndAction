package java.io;

import java.util.*;

/**
 * 
 */
public class File {

	/**
	 * Default constructor
	 */
	public File() {
	}




}