package java.util;

import java.util.*;

/**
 * 
 */
public class HashMap {

	/**
	 * Default constructor
	 */
	public HashMap() {
	}



}