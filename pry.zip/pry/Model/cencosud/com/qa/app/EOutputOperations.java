package cencosud.com.qa.app;

/**
 * 
 */
public enum EOutputOperations
{
  CREATE, CLOSE, WRITE 
}