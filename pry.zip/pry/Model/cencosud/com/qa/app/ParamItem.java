package cencosud.com.qa.app;

import java.util.*;

/**
 * 
 */
public class ParamItem {

	/**
	 * Default constructor
	 */
	public ParamItem() {
	}

	/**
	 * 
	 */
	public String pattern;

	/**
	 * 
	 */
	public String convId;



}