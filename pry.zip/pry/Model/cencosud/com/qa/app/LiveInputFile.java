package cencosud.com.qa.app;

import java.util.*;

/**
 * 
 */
public class LiveInputFile {

 /**
  * @param classToCall
  */
 public LiveInputFile(IReceptLine classToCall) {
  // TODO implement here
 }

}