package cencosud.com.qa.app;

import java.util.*;
import java.io.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

/**
 * De acuerdo al parámetro <mode> del TAAXmlFile se crea una instancia de LiveInputfile o FullInputFile.
 * Al crear esta instancia y se le pasa como parámetro la instancia de la clase ProcessLines.
 * En estas clases (LiveInputfile o FullInputFile) se llama a la función doProcessLine de la clase que implementa la interfaz IReceptLine.
 */
public class Loader {

  /**
   * 
   */
  private TAAXmlFile xmlFile;
  private ProcessLines process;
  private OutputFile outputFile;
  
  /**
  * Default constructor
  */
 public Loader() {
   IReceptLine readerInputFile;
   xmlFile = TAAXmlFile.getInstance();
   outputFile = new OutputFile();
   process = new ProcessLines(outputFile);

   readXMLFile();

   if (xmlFile.mode == 0){
     //Se crea el objeto de lectura secuencial activada por cambios
    readerInputFile = new LiveInputFile(process);
   }else{
     //Se crea el objeto de lectura completa del archivo estático
    readerInputFile = new FullInputFile(process);
   }
   
 }


 /**
  * 
  */
 public void readXMLFile() {
  // TODO implement here
   try{
     File fisicXMLFile = new File("/config.xml");
     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
     DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
     Document doc = dBuilder.parse(fisicXMLFile);
     
     doc.getDocumentElement().normalize();
     
    //Parseo de los tag del archivo
     //Tag de configuraci�n inicial <config>
     Element configNode = (Element) doc.getElementsByTagName("config").item(0);
     xmlFile.inputFilePath = ((Element) configNode.getElementsByTagName("origin").item(0)).getTextContent();
     xmlFile.lineStacked = Integer.parseInt(configNode.getElementsByTagName("linesstacked").item(0).getTextContent());
     xmlFile.mode = Integer.parseInt(configNode.getElementsByTagName("mode").item(0).getTextContent());
     
     //Tags con expresiones regulares de coincidencia inicial <expressions>
     NodeList expressionsNodeList = doc.getElementsByTagName("expressions").item(0).getChildNodes();

     for (int i = 0; i < expressionsNodeList.getLength(); i++){

       Node checkNodeList = expressionsNodeList.item(i);
       Element checkElement = (Element) checkNodeList;
       
       CheckClass tempCheckItem = new CheckClass(
            checkElement.getAttribute("pattern"),
            checkElement.getAttribute("match"),
            Integer.parseInt(checkElement.getAttribute("submatchlevel"))
          );
        
        //Tag de parámetros de cada check
        NodeList parametersNodeList = checkNodeList.getChildNodes();
        
        for (int j = 0; j < parametersNodeList.getLength(); j++){
          Node parametersNode = parametersNodeList.item(j);
          Element parameterElement = (Element) parametersNode;
          
          tempCheckItem.parameters.add( new ParametersCheckClass(
              parameterElement.getNodeName(),
              parameterElement.getAttribute("pattern"),
              parameterElement.getAttribute("conv_id")
            ));

        }
        
      }
      
      //Tag de string de conversion según su ID <conversions>
      NodeList conversionsNodeList = ((Element) doc.getElementsByTagName("conversions").item(0)).getElementsByTagName("conv");
     
      for (int i = 0; i < conversionsNodeList.getLength(); i++){
        Node convNode = conversionsNodeList.item(i);
        Element convElement = (Element) convNode;

        HashMap<String, ConversionItem> tempHashConversionItem = new HashMap<String, ConversionItem>();
        tempHashConversionItem.put(
          convElement.getAttribute("id"),
          new ConversionItem(
            convElement.getAttribute("input"),
            convElement.getAttribute("output")
          ));
      }

      //Tag de configuraciòn del archivo de salida <output file>
      Element outputFileElement = (Element) doc.getElementsByTagName("outputfile").item(0);
      xmlFile.outputFileDetails = new OutputFileXMLDetail(
        outputFileElement.getAttribute("extension"),
        outputFileElement.getAttribute("prename"),
        ((Element) outputFileElement.getElementsByTagName("automatic").item(0)).getAttribute("create_on"),
        ((Element) outputFileElement.getElementsByTagName("automatic").item(0)).getAttribute("close_on"),
        ((Element) outputFileElement.getElementsByTagName("header").item(0)).getTextContent(),
        ((Element) outputFileElement.getElementsByTagName("footer").item(0)).getTextContent()
      );
     
   }catch(IOException e){
     System.out.println(e);
   }
 }

}