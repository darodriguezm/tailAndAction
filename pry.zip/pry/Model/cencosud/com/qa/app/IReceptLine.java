package cencosud.com.qa.app;

import java.util.*;

/**
 * 
 */
public interface IReceptLine {

 /**
  * 
  */
 public void doProcessLine(String lineToProcess);
}