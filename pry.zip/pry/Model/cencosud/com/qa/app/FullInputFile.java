package cencosud.com.qa.app;

import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 * 
 */
public class FullInputFile {

 private File archivoTXT;
 private FileReader fileReader;
 private BufferedReader bufferReader;

 /**
  * @param classToCall
  */
 public FullInputFile(IReceptLine classToCall) {
  // TODO implement here
  TAAXmlFile xmlInstance = TAAXmlFile.getInstance();

  try {
   archivoTXT = new File(xmlInstance.inputFilePath);
   fileReader = new FileReader(archivoTXT);
   bufferReader = new BufferedReader(fileReader);

   String linea;

   while ( (linea = bufferReader.readLine()) != null) {
    classToCall.doProcessLine(linea);
   }

   fileReader.close();
   bufferReader.close();
   
  } catch (Exception e) {
   //TODO: handle exception
   System.out.println(e);
  }
 }

}