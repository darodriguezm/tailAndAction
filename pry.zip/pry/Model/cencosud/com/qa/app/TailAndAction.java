package cencosud.com.qa.app;

import java.util.*;

/**
 * 
 */
public class TailAndAction {

	/**
	 * Default constructor
	 */
	public TailAndAction() {
	}


	/**
	 * 
	 */
	private static void Main() {
		// TODO implement here
		Loader loadAndRun = new Loader();
	}

}