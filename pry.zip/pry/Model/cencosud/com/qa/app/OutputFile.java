package cencosud.com.qa.app;

import java.util.*;
import java.io.*;

/**
 * 
 */
public class OutputFile implements IOutputResult {

 /**
  * 
  */
 private File outputFile;
 private TAAXmlFile xmlInstance = TAAXmlFile.getInstance();

 public OutputFile() {
  // TODO implement here
 }

  /**
  * @param operation 
 * @param processResult
 */
 public void doProcessOutput(EOutputOperations operation, String processResult) {
  // TODO implement here
  
  EOutputOperations outputOperations;
  
  switch (operation) {
   case outputOperations.CREATE:
    break;

   case outputOperations.CLOSE:
    break;

   case outputOperations.WRITE:
    break;

  }
 }

}